
//
//  NavigationViewController.m
//  StandardArchitecture
//
//  Created by lujh on 2017/7/7.
//  Copyright © 2017年 lujh. All rights reserved.
//

#import "NavigationViewController.h"
#import "UIBarButtonItem+MSExtension.h"
@interface NavigationViewController ()<UINavigationControllerDelegate>

@end

@implementation NavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

#pragma mark -拦截Push事件

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    
    if (self.childViewControllers.count > 0) {
        viewController.hidesBottomBarWhenPushed = YES;
        [self setupBack:viewController];
    }
    
     [super pushViewController:viewController animated:animated];
}
#pragma mark - Setup

- (void)setupBack:(UIViewController *)viewController {
    UIBarButtonItem *backItem = [UIBarButtonItem itemWithImageName:@"navbar_back_white"
                                                     highImageName:@"navbar_back_white"
                                                            target:self
                                                            action:@selector(didTapBack:)];
    viewController.navigationItem.leftBarButtonItem = backItem;
}

#pragma mark - Action

- (void)didTapBack:(UIBarButtonItem *)sender {
    UIViewController *viewController = [self viewControllers].lastObject;
    if ([viewController respondsToSelector:@selector(didTapBack:)]) {
        [viewController performSelector:@selector(didTapBack:) withObject:sender];
    } else {
        [self popViewControllerAnimated:YES];
    }
}
@end
